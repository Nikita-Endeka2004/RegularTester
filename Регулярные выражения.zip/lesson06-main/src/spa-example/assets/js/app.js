
    const URL = 'https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?json';

   